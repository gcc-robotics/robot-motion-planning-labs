# generated from catkin/cmake/template/pkg.context.pc.in
CATKIN_PACKAGE_PREFIX = ""
PROJECT_PKG_CONFIG_INCLUDE_DIRS = "/home/sb161/ros_labs_ws/src/object_detect/src/".split(';') if "/home/sb161/ros_labs_ws/src/object_detect/src/" != "" else []
PROJECT_CATKIN_DEPENDS = "roscpp;std_msgs;sensor_msgs;message_runtime".replace(';', ' ')
PKG_CONFIG_LIBRARIES_WITH_PREFIX = "".split(';') if "" != "" else []
PROJECT_NAME = "object_detect"
PROJECT_SPACE_DIR = "/home/sb161/ros_labs_ws/src/object_detect/devel"
PROJECT_VERSION = "0.0.0"
