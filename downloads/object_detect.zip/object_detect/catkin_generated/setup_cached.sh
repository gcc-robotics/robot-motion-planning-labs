#!/usr/bin/env sh
# generated from catkin/python/catkin/environment_cache.py

# based on a snapshot of the environment before and after calling the setup script
# it emulates the modifications of the setup script without recurring computations

# new environment variables

# modified environment variables
export CMAKE_PREFIX_PATH="/home/sb161/ros_labs_ws/src/object_detect/devel:$CMAKE_PREFIX_PATH"
export CPATH="/home/sb161/ros_labs_ws/src/object_detect/devel/include:$CPATH"
export LD_LIBRARY_PATH="/home/sb161/ros_labs_ws/src/object_detect/devel/lib:/home/sb161/ros_labs_ws/src/object_detect/devel/lib/x86_64-linux-gnu:/home/sb161/ros_labs_ws/devel/lib/x86_64-linux-gnu:/home/sb161/turtlebot/devel/lib/x86_64-linux-gnu:/home/sb161/kobuki/devel/lib/x86_64-linux-gnu:/home/sb161/rocon/devel/lib/x86_64-linux-gnu:/opt/ros/indigo/lib/x86_64-linux-gnu:/home/sb161/ros_labs_ws/devel/lib:/home/sb161/turtlebot/devel/lib:/home/sb161/kobuki/devel/lib:/home/sb161/rocon/devel/lib:/opt/ros/indigo/lib:/opt/ros/indigo/lib/python2.7/dist-packages:/home/sb161/turtlebot/install/lib/python2.7/dist-packages:/home/sb161/turtlebot/install/lib/python2.7/dist-packages"
export PATH="/home/sb161/ros_labs_ws/src/object_detect/devel/bin:$PATH"
export PKG_CONFIG_PATH="/home/sb161/ros_labs_ws/src/object_detect/devel/lib/pkgconfig:/home/sb161/ros_labs_ws/src/object_detect/devel/lib/x86_64-linux-gnu/pkgconfig:/home/sb161/ros_labs_ws/devel/lib/x86_64-linux-gnu/pkgconfig:/home/sb161/turtlebot/devel/lib/x86_64-linux-gnu/pkgconfig:/home/sb161/kobuki/devel/lib/x86_64-linux-gnu/pkgconfig:/home/sb161/rocon/devel/lib/x86_64-linux-gnu/pkgconfig:/opt/ros/indigo/lib/x86_64-linux-gnu/pkgconfig:/home/sb161/ros_labs_ws/devel/lib/pkgconfig:/home/sb161/turtlebot/devel/lib/pkgconfig:/home/sb161/kobuki/devel/lib/pkgconfig:/home/sb161/rocon/devel/lib/pkgconfig:/opt/ros/indigo/lib/pkgconfig"
export PYTHONPATH="/home/sb161/ros_labs_ws/src/object_detect/devel/lib/python2.7/dist-packages:$PYTHONPATH"
export ROSLISP_PACKAGE_DIRECTORIES="/home/sb161/ros_labs_ws/src/object_detect/devel/share/common-lisp:$ROSLISP_PACKAGE_DIRECTORIES"
export ROS_PACKAGE_PATH="/home/sb161/ros_labs_ws/src/object_detect:$ROS_PACKAGE_PATH"