#include <iostream>
#include <stdio.h>

#include "ros/ros.h"
#include "objectDetector.cpp"

int main(int argc, char **argv)
{
	// Start Node
	ROS_INFO("Starting object_detect_node");

	ros::init(argc, argv, "object_detect");
	ros::NodeHandle node;

	// Start trash detector
	ObjectDetector o = ObjectDetector(node);
	ROS_INFO("Press Ctrl-C to kill node.");

	// Spin
	// ros::Rate loopRate(10); // 10 hz

	// while(ros::ok())
	// {
	// 	// Do other things?

	// 	// ROS Spin & Sleep
	// 	ros::spinOnce();
	// 	loopRate.sleep();
	// }

	ros::spin();

	ros::shutdown();

	return 0;
}
