#include <image_transport/image_transport.h>
#include "ros/ros.h"

#ifndef __objectDetector_H_
#define __objectDetector_H_


class ObjectDetector
{
private:
	ros::NodeHandle node;
	ros::Subscriber subscriber;

public:
	ObjectDetector(ros::NodeHandle rosNode);
	void processImage(const sensor_msgs::ImageConstPtr& msg);
};

#endif
